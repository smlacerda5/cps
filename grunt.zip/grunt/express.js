module.exports = {
	options: {
		port: 3000,
	},
	dev: {
		options: {
			script: 'keystone.js',
			debug: true,
		},
	},
};
