module.exports = {
	custom: {
		options: {
			'web-host': 'localhost',
		},
	},
};
