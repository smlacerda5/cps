module.exports = {
	dist: {
		files: {
			'public/styles/site.css': 'public/styles/site.less',
		},
	},
};
